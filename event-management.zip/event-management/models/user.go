package models

type User struct {
	Id                int
	Email             string
	Password          string
	Name              string
	Bio               string
	ProfilePictureKey string
}
